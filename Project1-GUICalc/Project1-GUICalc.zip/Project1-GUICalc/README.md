#Description Of Project

#simple GUI calculator app using Python Tkinter



